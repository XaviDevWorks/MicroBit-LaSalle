def on_forever():
    pass
basic.forever(on_forever)
