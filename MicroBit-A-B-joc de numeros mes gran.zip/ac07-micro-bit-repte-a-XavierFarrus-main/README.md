
> Obre aquesta pàgina a [https://raimonizard.github.io/microbit-template-repo/](https://raimonizard.github.io/microbit-template-repo/)

## Utilitza-ho com a extensió

Aquest dipòsit es pot afegir com una **extensió** a MakeCode.

* obre [https://makecode.microbit.org/](https://makecode.microbit.org/)
* fes clic a **Projecte nou**
* fes clic a **Extensions** sota el menú de la roda dentada
* cercar **https://github.com/raimonizard/microbit-template-repo** i importar

## Edita aquest projecte

Per editar aquest repositori a MakeCode.

* obre [https://makecode.microbit.org/](https://makecode.microbit.org/)
* fes clic a ** Importa** i després a ** Importa URL**
* enganxa **https://github.com/raimonizard/microbit-template-repo** i clica importar

#### Metadades (utilitzades per a la cerca, renderització)

* for PXT/microbit
<script src="https://makecode.com/gh-pages-embed.js"></script><script>makeCodeRender("{{ site.makecode.home_url }}", "{{ site.github.owner_name }}/{{ site.github.repository_name }}");</script>
