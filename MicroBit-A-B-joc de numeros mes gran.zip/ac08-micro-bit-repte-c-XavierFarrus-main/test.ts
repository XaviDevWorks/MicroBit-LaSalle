// les proves van aquí; això no es compilarà quan aquest paquet s'usi com a extensió.
